#include <winsock2.h>
#ifdef JSPRINTERDLL_EXPORTS
#define JSPRINTERDLL_API __declspec(dllexport)
#else
#define JSPRINTERDLL_API __declspec(dllimport)
#endif



/********Functions to be called on Lan port**************/
JSPRINTERDLL_API BOOL _stdcall InitNetSev(); 

JSPRINTERDLL_API int _stdcall ConnectNetPort(SOCKET *lpSocket,
	SOCKADDR_IN * pPrinterAddr,   
	timeval *lpTimeout);  

JSPRINTERDLL_API int _stdcall WriteToNetPort(SOCKET *lpSocket,
	char *SendBuf,
	DWORD SendBufSize);

JSPRINTERDLL_API int _stdcall ReadFromNetPort(SOCKET *lpSocket,
	char *RecvBuf,    
	DWORD RecvBufSize);  

JSPRINTERDLL_API BOOL _stdcall CloseNetPor(SOCKET *lpSocket);

JSPRINTERDLL_API  BOOL _stdcall CloseNetServ();





/********Functions to be called on USB port**************/
JSPRINTERDLL_API HANDLE  _stdcall OpenUsb();


JSPRINTERDLL_API BOOL  _stdcall WriteUsb(HANDLE hUsb,
	char *SendBuf,								
	DWORD SendBufSize,							
	LPDWORD lpNumberOfBytesWriten);				


JSPRINTERDLL_API BOOL  _stdcall ReadUsb(HANDLE hUsb,                
char *ReadBuf,               
DWORD ReadBufSize,			
LPDWORD lpNumberOfBytesRead); 
JSPRINTERDLL_API BOOL  _stdcall CloseUsb(HANDLE hUsb);





/********Functions to be called on Lpt port**************/
JSPRINTERDLL_API HANDLE  _stdcall OpenLptW(LPCWSTR LptName);
JSPRINTERDLL_API HANDLE  _stdcall OpenLptA(LPCSTR lpLptName); 

JSPRINTERDLL_API BOOL _stdcall WriteLpt(HANDLE hLpt,
	 char *SendBuf,
	 DWORD SendBufSize,
	 LPDWORD BytesWritten);

JSPRINTERDLL_API BOOL _stdcall CloseLpt(HANDLE hLpt);


/****************Functions to be called on Serial port**************/
JSPRINTERDLL_API HANDLE _stdcall OpenComW(LPCWSTR lpCom,DWORD BaudRate);

JSPRINTERDLL_API HANDLE _stdcall OpenComA(LPCSTR lpCom,DWORD BaudRate);

JSPRINTERDLL_API BOOL _stdcall ReadCom(HANDLE hCom,                
			 char *ReadBuf,               
			 DWORD ReadBufSize, 
			 LPDWORD lpNumberOfBytesRead); 

JSPRINTERDLL_API BOOL _stdcall WriteCom(HANDLE hCom,char *SendBuf,DWORD SendBufSize,LPDWORD BytesWritten);

JSPRINTERDLL_API BOOL _stdcall CloseCom(HANDLE hCom);

