// COMDlg.h : header file
//

#if !defined(AFX_COMDLG_H__7F7533C4_3396_4928_8D51_6BCFF985CC5A__INCLUDED_)
#define AFX_COMDLG_H__7F7533C4_3396_4928_8D51_6BCFF985CC5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCOMDlg dialog

class CCOMDlg : public CDialog
{
// Construction
public:
	CCOMDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCOMDlg)
	enum { IDD = IDD_COM_DIALOG };
	BOOL	bHex;
	int		iPrintNum;
	CString	m_strTx;
	DWORD dwBote;
	CString strComName;
	HANDLE hCom;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCOMDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCOMDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeComboCom();
	afx_msg void OnSelchangeComboBote();
	afx_msg void OnButtonAdd();
	afx_msg void OnButtonJian();
	afx_msg void OnButtonClr();
	afx_msg void OnButtonPrint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMDLG_H__7F7533C4_3396_4928_8D51_6BCFF985CC5A__INCLUDED_)
