// COMDlg.cpp : implementation file
//

#include "stdafx.h"
#include "COM.h"
#include "COMDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

	#include "JsPrinterDll.h"
#pragma comment(lib, "JsPrinterDll")

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCOMDlg dialog

CCOMDlg::CCOMDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCOMDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCOMDlg)
	bHex = FALSE;
	iPrintNum = 1;
	m_strTx = _T("��ӭʹ��רҵPOSƱ�ݴ�ӡ����˾�������������ϵ�д�ӡ��!\n");
	dwBote=9600;
	strComName="COM1";
	hCom=INVALID_HANDLE_VALUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCOMDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCOMDlg)
	DDX_Check(pDX, IDC_CHECK_HEX, bHex);
	DDX_Text(pDX, IDC_EDIT_PRINTNUM, iPrintNum);
	DDV_MinMaxInt(pDX, iPrintNum, 1, 1000);
	DDX_Text(pDX, IDC_EDIT_TX, m_strTx);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCOMDlg, CDialog)
	//{{AFX_MSG_MAP(CCOMDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO_COM, OnSelchangeComboCom)
	ON_CBN_SELCHANGE(IDC_COMBO_BOTE, OnSelchangeComboBote)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_JIAN, OnButtonJian)
	ON_BN_CLICKED(IDC_BUTTON_CLR, OnButtonClr)
	ON_BN_CLICKED(IDC_BUTTON_PRINT, OnButtonPrint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCOMDlg message handlers

BOOL CCOMDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	((CComboBox*)GetDlgItem(IDC_COMBO_COM))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_BOTE))->SetCurSel(3);

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCOMDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCOMDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCOMDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



void CCOMDlg::OnSelchangeComboCom() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	((CComboBox*)GetDlgItem(IDC_COMBO_COM))->GetWindowText(strComName);
}

void CCOMDlg::OnSelchangeComboBote() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	switch(((CComboBox*)GetDlgItem(IDC_COMBO_BOTE))->GetCurSel())
	{
	case 0:
		dwBote=1200;
		break;
	case 1:
		dwBote=2400;
		break;
	case 2:
		dwBote=4800;
		break;
	case 3:
		dwBote=9600;
		break;
	case 4:
		dwBote=19200;
		break;
	default:
		dwBote=9600;
		break;
	}
}

void CCOMDlg::OnButtonAdd() 
{
	// TODO: Add your control notification handler code here
	iPrintNum++;
	UpdateData(FALSE);
}

void CCOMDlg::OnButtonJian() 
{
	// TODO: Add your control notification handler code here
	iPrintNum--;
	if(iPrintNum<=0)
	{
		iPrintNum=1;
	}
	UpdateData(FALSE);
}

void CCOMDlg::OnButtonClr() 
{
	// TODO: Add your control notification handler code here
	m_strTx.Empty();
	UpdateData(FALSE);
}

extern int String2Hex(char *SendStr, char *SendHex);

void CCOMDlg::OnButtonPrint() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_strTx.GetLength()==0)
	{
		AfxMessageBox("��������Ϊ��!");
		return ;
	}
	SetTimer(1,5000,NULL);   //���ö�ʱ��Ϊ5000ms=5s, ʱ�䵽��ִ��OnTimer()�رմ򿪵�USB���; 
	if(hCom==INVALID_HANDLE_VALUE)
	{
		if((hCom=OpenComA((LPCSTR)strComName,dwBote))==INVALID_HANDLE_VALUE)
		{
			AfxMessageBox(_T("��Com��ʧ��"));
			return;
		}
	}
	char *sendbuf;
    sendbuf=(LPTSTR)(LPCTSTR)m_strTx;
	DWORD Bytes=strlen(sendbuf);
	DWORD BytesWriten;
	if(bHex==1)  //ʮ�����Ʒ���
	{
		char *SendHex=new char[Bytes/2];
		DWORD HexLength;
		HexLength=String2Hex(sendbuf,SendHex);
		if(HexLength==0)
		{
			CloseCom(hCom); 
			hCom=INVALID_HANDLE_VALUE;
			AfxMessageBox(_T("�ַ���������"));
			return;
		}
		if(!WriteCom(hCom,SendHex,HexLength,&BytesWriten))  
		{
			AfxMessageBox(_T("д��ʧ��"));
			CloseCom(hCom); 
			hCom=INVALID_HANDLE_VALUE;
		}
		delete[] SendHex;
	}
	else
	{
		int i=iPrintNum;       //��ӡ����
		while(i--)
		{
			if(!WriteCom(hCom,sendbuf,Bytes,&BytesWriten))  
			{
				AfxMessageBox(_T("д��ʧ��"));
			}
		}//end while 
	}
	CloseUsb(hCom); 
	hCom=INVALID_HANDLE_VALUE;
}


void CCOMDlg::OnOK()
{
	
}