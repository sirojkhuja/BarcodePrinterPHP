// UsbExampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UsbExample.h"
#include "UsbExampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include  "JsPrinterDll.h"              //����JsDll.dll��ͷ�ļ�
#pragma comment(lib, "JsPrinterDll")    //����JsDll.dll�����ӿ�


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsbExampleDlg dialog

CUsbExampleDlg::CUsbExampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUsbExampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUsbExampleDlg)
	iPrintNum = 1;
	TxData = _T("��ӭʹ��רҵPOSƱ�ݴ�ӡ����˾�������������ϵ�д�ӡ��!\r\n");
	hUsb=INVALID_HANDLE_VALUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUsbExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUsbExampleDlg)
	DDX_Control(pDX, IDC_CHECK1, m_ctrlHexSend);
	DDX_Text(pDX, IDC_EDIT2, iPrintNum);
	DDX_Text(pDX, IDC_EDIT1, TxData);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUsbExampleDlg, CDialog)
	//{{AFX_MSG_MAP(CUsbExampleDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnPrint)
	ON_BN_CLICKED(IDC_BUTTON1, OnClrData)
	ON_BN_CLICKED(IDC_BUTTON3, OnAdd)
	ON_BN_CLICKED(IDC_BUTTON4, OnJian)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON5, OnPrint)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsbExampleDlg message handlers

BOOL CUsbExampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUsbExampleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUsbExampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUsbExampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


int String2Hex(char *SendStr, char *SendHex);  //ʮ������ת��


/***************************��ӡ��ť�Ĵ���*******************************/
/**���ڴ˳�������������USB��ӡ���豸�Ĵ�ӡ���ԣ���Ҫ����������ӡ���豸****
***��˳�����������һ����ʱ����ÿ��5���йرմ򿪵�USb��ӡ�豸�������ʱ***
***����Ƶ����ʹ��OpenUsb()��CloseUsb()�����������ӡ�豸����Ƶ��������****
***��ôʹ��OpenUsb()����һ�ν��ж�д������OK�ˣ�***********************/
void CUsbExampleDlg::OnPrint() 
{
	// TODO: Add your control notification handler code here
	SetTimer(1,5000,NULL);   //���ö�ʱ��Ϊ5000ms=5s, ʱ�䵽��ִ��OnTimer()�رմ򿪵�USB���; 
	if(hUsb==INVALID_HANDLE_VALUE)
	{
		hUsb=OpenUsb();
		if(hUsb==INVALID_HANDLE_VALUE)
		{
			AfxMessageBox(_T("��USB�豸ʧ��"));
			return;
		}
	}
	UpdateData(TRUE);
	char *sendbuf;
    sendbuf=(LPTSTR)(LPCTSTR)TxData;
	DWORD Bytes=strlen(sendbuf);
	DWORD BytesWriten;

	/***********************����HEX******************/
	if(m_ctrlHexSend.GetCheck())//����ʮ����������
	{
		char *SendHex=new char[Bytes/2];
		DWORD HexLength;
		HexLength=String2Hex(sendbuf,SendHex);
		if(HexLength==0)
		{
			CloseUsb(hUsb); 
			hUsb=INVALID_HANDLE_VALUE;
			AfxMessageBox(_T("�ַ���������"));
			return;
		}
		if(!WriteUsb(hUsb,SendHex,HexLength,&BytesWriten))  
		{
			AfxMessageBox(_T("д��ʧ��"));
			CloseUsb(hUsb); 
			hUsb=INVALID_HANDLE_VALUE;
		}
		delete[] SendHex;
		return ;
	}//end if 

	/*******************�����ַ���*********************/
	int i=iPrintNum;       //��ӡ����
	while(i--)
	{
		if(!WriteUsb(hUsb,sendbuf,Bytes,&BytesWriten))  
		{
			AfxMessageBox(_T("д��ʧ��"));
			CloseUsb(hUsb); 
			hUsb=INVALID_HANDLE_VALUE;
			return;
		}
	}//end while 
}

void CUsbExampleDlg::OnClrData() //��շ�������ť
{
	// TODO: Add your control notification handler code here
	TxData.Empty();
	UpdateData(FALSE);
}

void CUsbExampleDlg::OnAdd() //��ӡ�����ļӰ�ť
{
	// TODO: Add your control notification handler code here
	iPrintNum++;
	UpdateData(FALSE);
}

void CUsbExampleDlg::OnJian()  //��ӡ�����ļ���ť
{
	// TODO: Add your control notification handler code here
	iPrintNum--;
	if(iPrintNum<=0)
	{
		iPrintNum=1;
	}
	UpdateData(FALSE);
}


void CUsbExampleDlg::OnDestroy()   //�����˳�ʱ
{
	CDialog::OnDestroy();
	CloseUsb(hUsb);      //�����ٴ����˳�ʱ���ͷŴ򿪵�Usb��Դ
	// TODO: Add your message handler code here
}

void CUsbExampleDlg::OnTimer(UINT nIDEvent)   //��ʱ��
{
	// TODO: Add your message handler code here and/or call default
	KillTimer(1);    //5��ʱ�䵽��ɱ����ʱ����
	CloseUsb(hUsb);           //ʱ�䵽,�رմ򿪵�USB�豸��
	hUsb=INVALID_HANDLE_VALUE;    //�����Ϊ��Ч�Ա��´δ�
}

void CUsbExampleDlg::OnOK()
{
	
}