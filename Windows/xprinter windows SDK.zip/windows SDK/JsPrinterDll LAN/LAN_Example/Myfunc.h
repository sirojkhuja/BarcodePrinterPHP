#include "stdafx.h"
#include "LAN.h"
#include "LANDlg.h"

void _stdcall GetHostName(LPDWORD lpLocalAddress);

