#include "stdafx.h"
#include "LAN.h"
#include "LANDlg.h"
#include "JsPrinterDll.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



#include "JsPrinterDll.h"
#pragma comment(lib, "JsPrinterDll")
#pragma comment(lib, "ws2_32.lib")


void _stdcall GetHostName(LPDWORD lpLocalAddress)
{
	hostent* host = gethostbyname("");
	char *cIP = inet_ntoa(*(struct in_addr*)*(host->h_addr_list));
	*lpLocalAddress=htonl(inet_addr(cIP));
}

