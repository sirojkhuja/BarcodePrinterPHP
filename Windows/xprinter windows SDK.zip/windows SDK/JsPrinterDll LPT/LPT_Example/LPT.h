// LPT.h : main header file for the LPT application
//

#if !defined(AFX_LPT_H__9ED73AFC_A9F9_4C76_898B_4C91A860E292__INCLUDED_)
#define AFX_LPT_H__9ED73AFC_A9F9_4C76_898B_4C91A860E292__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLPTApp:
// See LPT.cpp for the implementation of this class
//

class CLPTApp : public CWinApp
{
public:
	CLPTApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLPTApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLPTApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LPT_H__9ED73AFC_A9F9_4C76_898B_4C91A860E292__INCLUDED_)
